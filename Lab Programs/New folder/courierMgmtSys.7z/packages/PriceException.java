package packages;

public class PriceException extends Exception {
	PriceException (String s) {
		super(s);
	}
}
